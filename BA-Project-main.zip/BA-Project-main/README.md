# BA-Project
For Business Analytics Project
Project Proposal
